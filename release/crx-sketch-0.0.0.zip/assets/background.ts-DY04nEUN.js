import{b as r}from"./browser-polyfill-DMmbowld.js";r.runtime.onMessage.addListener(async e=>(console.log("Message recievend in backend Script",e),{text:"Message from Background Script"}));
